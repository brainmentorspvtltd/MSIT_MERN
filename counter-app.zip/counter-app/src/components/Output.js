export const Output = ({message})=>{
    console.log("Render Output ");
    return (<h3>{message}</h3>)
}