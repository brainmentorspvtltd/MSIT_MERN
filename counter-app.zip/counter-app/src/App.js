import { Counter } from "./pages/Counter";

 const App = ()=>{
  return (<Counter/>); // JSX
}
export default App; 

export const X = 10;

export const Y = {
  a:10, b:20, c:30
}
