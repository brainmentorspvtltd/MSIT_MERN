import { nativeOperations } from "../services/native"

export const Gps = ()=>{
    const successFn = (pos)=>{
        console.log('Success Call ', pos);
    }
    const failFn = (err)=>{
        console.log('Fail Call ', err);
    }
    const getLocation = ()=>{
            nativeOperations.gps(successFn, failFn);
            console.log('Test');
    }
    return <button onClick={getLocation}>Get Location</button>
}