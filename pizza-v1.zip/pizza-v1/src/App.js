import logo from './logo.svg';
import './App.css';
import { Gps } from './shared/widgets/Gps';

function App() {
  return (
   <Gps/>
  );
}

export default App;
