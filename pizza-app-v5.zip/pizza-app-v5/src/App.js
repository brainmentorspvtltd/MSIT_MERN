import logo from './logo.svg';
import './App.css';
import { Gps } from './shared/widgets/Gps';
import { Product } from './modules/products/pages/Product';
import { Login } from './modules/user/pages/login';

function App() {
  return (
 <Login/>
  );
}

export default App;
