import { useEffect, useState } from "react";
import { API_CLIENT } from "../../../shared/services/api_client";

export const Drinks =()=>{
    const [drinks,setDrinks] = useState([]); 
    useEffect(()=>{
    getDrinksData();
    },[]);
    const getDrinksData  = ()=>{
        const promise = API_CLIENT.get(process.env.REACT_APP_DRINKS_URL);
        promise.then(result=>{
            console.log(result);
            setDrinks(result.data.drinks); // Re-rendering
        }).catch(err=>{
            console.log(err);
        })
    }
    return (<></>)
}