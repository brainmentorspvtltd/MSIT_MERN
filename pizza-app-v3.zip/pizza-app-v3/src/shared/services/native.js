export const nativeOperations = {
    mic(){

    },
    gps(success, fail){
        console.log('GPS Call Fn Start');
        navigator.geolocation.getCurrentPosition((loc)=>{
          
                const pos = {"lat":loc.coords.latitude,"lng":loc.coords.longitude};
                success(pos);
        }, (err)=>{
                fail(err);
        })
        console.log('GPS Call Fn Ends');
    }
}