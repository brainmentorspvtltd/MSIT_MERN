import logo from './logo.svg';
import './App.css';
import { Gps } from './shared/widgets/Gps';
import { Product } from './modules/products/pages/Product';

function App() {
  return (
  <Product/>
  );
}

export default App;
