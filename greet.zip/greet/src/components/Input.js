export const Input = ({labelValue, fn, val})=>{
    const placeHolder = `Type ${labelValue}`;
    return (<div className='form-group'>
    <label>{labelValue}</label>
    <input value = {val} onChange={fn}  className='form-control' type='text' placeholder = {placeHolder}/>
    </div>);
}