export const Output = ({result})=>{
    return (<h3>{result}</h3>)
}