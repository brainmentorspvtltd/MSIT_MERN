import Container from '@mui/material/Container';
import Box from '@mui/material/Box';
import { useEffect, useState } from 'react';
import { API_CLIENT } from '../../../shared/services/api_client';
import { MenuTab } from '../../../shared/widgets/Menu';

export const Product = ()=>{
    // const e = 10;
    // e++;
    const [category,setCategory] = useState([]); // Immutable  
    const [products,setProducts] = useState([]);
    useEffect(()=>{
        getMenuData();
        getPizzaData();
        
    },[]);  // Mount 
    useEffect(()=>{
       
        return function(){
            // Resource Clean Up
            setCategory(null);
            setProducts(null);
        }
    },[]); // Component Un Mount
    const getPizzaData  = ()=>{
        const promise = API_CLIENT.get(process.env.REACT_APP_PIZZA_URL);
        promise.then(result=>{
            console.log(result);
            setProducts(result.data.Vegetarian); // Re-rendering
        }).catch(err=>{
            console.log(err);
        })
    }
    const getMenuData = ()=>{
        const promise = API_CLIENT.get(process.env.REACT_APP_MENU_URL);
        promise.then(result=>{
            console.log(result);
            setCategory(result.data.category); // Re-rendering
        }).catch(err=>{
            console.log(err);
        })
    }
    return <>
    <Container maxWidth="sm">
        <Box sx={{ bgcolor: '#cfe8fc', height: '100vh' }} >
           <MenuTab category = {category}/>
            <div>
                {products.map(product=><>
                   
                <img src={product.assets.product_details_page[0].url}/>
                <p>{product.name} {product.price}</p>
                
                </>)}
            </div>
            </Box>
      </Container>
    </>
}