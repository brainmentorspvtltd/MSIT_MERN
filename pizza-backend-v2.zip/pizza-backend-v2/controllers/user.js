const userOperations = require('../db/respository/user_operations');
module.exports = {
    login(request, response){
        const userObject = request.body;
        console.log('Request Body is ', userObject);
        userOperations.read(userObject, response);
    //    // if(userObject.userid == userObject.password){
    //         response.json({message:'Welcome '+userObject.userid});
    //     }
    //     else{
    //         response.json({message:'Invalid Userid or Password'});
    //     }
    },
    async register(request,response){
        const userObject = request.body;
        const result  =await userOperations.add(userObject);
        if(result && result.userid){
            response.json({message:'Record Added'});
        }
        else{
            response.json({message:"Record not Added..."});
        }
    },
    profile(request, response){

    }
}