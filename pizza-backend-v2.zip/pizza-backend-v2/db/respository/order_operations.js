const OrderModel = require('../models/order_schema');
module.exports = {
    add(orderObject){
        return OrderModel.create(orderObject);
    },
    read(orderObject){
        UserModel.findOne({'orderid':orderObject.orderid}, (err,doc)=>{
            if(err){

            }
            else if(doc && doc.orderid){

            }
            else{
                        // doc = {}
            }
        });
    },
    update(userObject){
        UserModel.findOneAndUpdate({'userid':userObject.userid},{'password':userObject.password});
    },
    remove(userObject){

    }
}