const mongoose = require('mongoose');
const URL = "mongodb+srv://pizzauser:test123456@cluster0.y6jwf5b.mongodb.net/pizzaapp_msit?retryWrites=true&w=majority";


mongoose.connect(URL,(err)=>{
    if(err){
        console.log('Connection Error ', err);
    }
    else{
        console.log('Connected....');
    }
});
module.exports = mongoose;