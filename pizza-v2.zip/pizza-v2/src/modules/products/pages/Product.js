import Container from '@mui/material/Container';
import Box from '@mui/material/Box';
import { useEffect } from 'react';
import { API_CLIENT } from '../../../shared/services/api_client';
export const Product = ()=>{
    useEffect(()=>{
        const promise = API_CLIENT.get(process.env.REACT_APP_MENU_URL);
        promise.then(data=>{
            console.log(data);
        }).catch(err=>{
            console.log(err);
        })
    },[])
    return <>
    <Container maxWidth="sm">
        <Box sx={{ bgcolor: '#cfe8fc', height: '100vh' }} />
      </Container>
    </>
}