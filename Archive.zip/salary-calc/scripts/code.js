function compute(){
    // take text box value
    var basicSalary = document.getElementById('salary').value;
    var hra = basicSalary * 0.50;
    var da = basicSalary * 0.20;
    document.getElementById('hra').innerText = hra;
    document.getElementById('da').innerText = da;

    console.log("I am Compute...");
}