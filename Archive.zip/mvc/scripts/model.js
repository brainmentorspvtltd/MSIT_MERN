// hra , da, ta , gs functions

// eg.
function hra(basicSalary){
    return basicSalary * 0.50;
}
