// Input from TextBox

// Call the model


// Print the result on span tag