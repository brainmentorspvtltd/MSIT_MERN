// const fs = require('fs');
// fs.watchFile('/Users/amitsrivastava/Documents/mern-msit/ownserver/score.txt', (current, prev)=>{
//     console.log('Score Change ');
//     const result =fs.readFileSync('/Users/amitsrivastava/Documents/mern-msit/ownserver/score.txt');
//     console.log(result.toString());
// })
// const chokidar = require('chokidar');

// chokidar.watch('.').on('all', (event, path) => {
//     console.log(event, path);
//   });