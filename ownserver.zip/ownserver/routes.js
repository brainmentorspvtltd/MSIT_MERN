const urlObject = require('url');
const routes = (url, request, response)=>{
    const method = request.method;
    if(url ==='/slow'){
        for(let i  =1 ; i<=100000; i++){
            for(let j = 1; j<500000; j++){

            }
        }
        response.write('Slow Task Done...');
        response.end();
    }
    else
    // Post - Request Body
    if(url =='/login' && method ==='POST'){
        let data = '';
        request.on('data',chunk=>{
            data +=chunk;
        })
        request.on('end',()=>{
            // const queryString = require('querystring');
            // const obj = queryString.parse(data);
            const urlParam = new URLSearchParams(data);
            const arr = [];
            urlParam.forEach((e,index)=>arr[index]=e);
            console.log("Array ",arr);
            //console.log('Data Ends ', obj);
            if(arr['userid'] == arr['pwd']){
                response.write('Welcome '+arr['userid']);
            }
            else{
                response.write('Invalid Userid or Password');
            }
            response.end();
        })
    }
    else 
    if(url =='/register'){

    }
    else
    if(url.startsWith('/profile') && method === 'GET'){
        // Get the data from the URL
        const r = urlObject.parse(url, true);
        console.log(r);
        response.write(r.query.user+' Profile is ');
        response.end();
    }
}
module.exports = routes;