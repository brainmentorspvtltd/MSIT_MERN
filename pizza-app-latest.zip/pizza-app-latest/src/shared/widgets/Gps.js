import { useState } from "react";
import { nativeOperations } from "../services/native"
import { Map } from "./Map";

export const Gps = ()=>{
    const [flag, setFlag] = useState(false);
    const [pos, setPos] = useState(null);
    const successFn = (pos)=>{
        console.log('Success Call ', pos);
        setPos(pos);
        setFlag(true);
    }
    const failFn = (err)=>{
        console.log('Fail Call ', err);
    }
    const getLocation = ()=>{
            nativeOperations.gps(successFn, failFn);
            console.log('Test');
    }
    return <>
    
    {flag? <Map pos = {pos}/>:<button onClick={getLocation}>Get Location</button>}
   
    <br/>
    
    </>
}