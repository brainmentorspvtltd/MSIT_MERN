export const Player = ()=>{
    let url = "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview115/v4/1f/3e/fe/1f3efe39-83ad-33d9-d538-4eaa3c13250b/mzaf_17256997476615367956.plus.aac.p.m4a";
    return (
    <>
    <audio controls>
       
        <source src={url} type="audio/mpeg"/>
     
      </audio>
      </>
      );
}