export const Icon = ()=>{
    return (<p>I am the Icon</p>);
}

