import { Icon } from "./Icon";

export const Menu = ()=>{
    return (
        <>
    <p>I am the Menu</p>
    <Icon/>
    </>
    );
}