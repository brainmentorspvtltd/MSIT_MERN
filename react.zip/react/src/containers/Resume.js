import { Menu } from "../components/Menu"

export const Resume = ()=>{
    // return (<h1> I am the Resume</h1>)
    return (<Menu/>)
}
// Smart Component
// class Resume extends React.Component{
// constructor(){
//     super();
// }
// render(){
//     return ();
// }
// }