import { Resume } from "./containers/Resume";

function App(){
  var year = 2022;
  // return (<h1>I am React JS..... {year}</h1>);
  return (<Resume/>);
}
export default App;