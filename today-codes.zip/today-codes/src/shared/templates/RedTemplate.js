export const RedTemplate = ()=>{
    return ();
    
}