import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import {Link} from 'react-router-dom';
import { useState } from 'react';
export const MenuTab = (props)=>{

    const [value, setValue] = useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

    return(<>
      {props.menus.map((c,index)=><Link to={c.url}>{c.name} &nbsp;</Link> )}

    {/* <Tabs value={value} onChange={handleChange} >
        {props.menus.map((c,index)=><Tab key={index} label={c.name}  />)}
    {/* { <Tab label="Item One"  />
    <Tab label="Item Two"  />
    <Tab label="Item Three"  /> } </></Tabs> }}*/ } 
  


</>
)
}