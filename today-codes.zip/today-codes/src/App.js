import logo from './logo.svg';
import './App.css';
import { Gps } from './shared/widgets/Gps';
import { Product } from './modules/products/pages/Product';
import { Login } from './modules/user/pages/login';
import { DragAndDropExample } from './modules/user/pages/DragAndDropExample';
import { DashBoard } from './modules/user/pages/DashBoard';
import { Player } from './modules/user/pages/Player';

function App() {
  return (<Player/>);
  //return (<DashBoard/>);
 // return (<DragAndDropExample/>);
//   return (
//  <Login/>
//   );
}

export default App;
