import { MenuTab } from "../../../shared/widgets/Menu"
import {Routes, Route} from 'react-router-dom';
import { Login } from "./login";
import { DragAndDropExample } from "./DragAndDropExample";
import { Product } from "../../products/pages/Product";
export const DashBoard = ()=>{
    const menus = [{name:"Login",url:"/"},{name:"Drag",url:"/drag"},{name:"Product",url:"/product"}];
    return (
    <>
    <MenuTab menus = {menus}/>
    <hr/>
    <Routes>
        <Route path="/" element={<Login/>}/>
        <Route path="/drag" element={<DragAndDropExample/>}/>
        <Route path="/product" element={<Product/>}/>
    </Routes>
    </>
    )
}