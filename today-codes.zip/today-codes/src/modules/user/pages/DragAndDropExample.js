import Draggable, {DraggableCore} from 'react-draggable';
 
export const DragAndDropExample = ()=>{
    const handleStart =(event, data)=>{
        console.log('Start ', event, ' Data ', data);
    }
    const handleDrag =(event, data)=>{
        console.log('Drag ', event, ' Data ', data);
    }
    const handleStop =(event, data)=>{
        console.log('Stop ', event, ' Data ', data);
    }
    return (
        <Draggable
          axis="x"
          handle=".handle"
          defaultPosition={{x: 0, y: 0}}
          position={null}
          grid={[25, 25]}
          scale={1}
          onStart={handleStart}
          onDrag={handleDrag}
          onStop={handleStop}>
          <div>
            <div className="handle">Drag from here</div>
            <div>This readme is really dragging on...</div>
          </div>
        </Draggable>
      );
}