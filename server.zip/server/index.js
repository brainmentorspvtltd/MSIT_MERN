const http = require('http');
const path = require('path');
const fs = require('fs');
function handleRequestAndResponse(request, response){
    console.log('Request Comes ... ', request.url);
    let url = request.url;
    if(url == '/'){
        url = '/index.html';
    }
    if(isStaticContent(url)){
        serveStaticContent(url, response);
    }
    else{
    response.write('Hello Client');
    response.end(); // Flush
    }
}

const  isStaticContent=(currentFileName)=>{
    const staticThings = [".html", ".jpeg",".css", ".js",".png",".gif"];
    const ext = path.extname(currentFileName);
    return staticThings.indexOf(ext)>=0;
}

const serveStaticContent = (url, response)=>{
    const publicFolder = "/public";
    const parentPath = __dirname;// Give Current Dir Path
    const fullpath = path.join(parentPath, publicFolder, url);
    console.log('Full path ', fullpath);
    const stream = fs.createReadStream(fullpath);
    stream.pipe(response);

    

}

// Serve Static Content

const server = http.createServer(handleRequestAndResponse);
server.listen(1234,err=>{
    if(err){
        console.log('Server Crash ',err);
    }
    else{
        console.log('Server Started ... ', server.address().port);
    }
})