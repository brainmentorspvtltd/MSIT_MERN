module.exports = {
    login(request, response){
        const userObject = request.body;
        console.log('Request Body is ', userObject);
        if(userObject.userid == userObject.password){
            response.json({message:'Welcome '+userObject.userid});
        }
        else{
            response.json({message:'Invalid Userid or Password'});
        }
    },
    register(request,response){

    },
    profile(request, response){

    }
}