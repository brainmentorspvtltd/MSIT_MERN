const express = require('express');
const routes = express.Router();
routes.post('/add-to-cart',(request, response)=>{
    
});
routes.post('/remove-from-cart',(request, response)=>{
    
});
routes.post('/view-cart',(request, response)=>{
    
});
routes.post('/update-cart',(request, response)=>{
    
})